/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!***************************!*\
  !*** ./assets/js/form.js ***!
  \***************************/
function btnClick() {
  alert(123);
}
/******/ })()
;